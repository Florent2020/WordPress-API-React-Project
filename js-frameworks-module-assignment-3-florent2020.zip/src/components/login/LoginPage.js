import Heading from "../layout/Heading";
import LoginForm from "./LoginForm";
import { useContext } from "react";
import AuthContext from "../../context/AuthContext";

export default function LoginPage() {

	const [auth, setAuth] = useContext(AuthContext);

	return (
		<>
			<Heading content="Login" />


			{auth ? (
				<>
				<div></div>
				</>
			) : (
				<LoginForm />
			)}
		</>
	);
}